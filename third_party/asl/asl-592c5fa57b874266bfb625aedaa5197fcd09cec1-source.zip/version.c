/* version.c */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Lagert die Versionsnummer                                                 */
/*                                                                           */
/*****************************************************************************/

#include "stdinc.h"

char const* Version    = "1.42 Beta [Bld 313]";
char const* DebVersion = "1.42bld313-1";
LongInt     VerNo      = 0x142f;

char const* InfoMessCopyright = "(C) 1992-2026 Alfred Arnold";
char const* InfoNewCopyright  = "(C) 2022-2026 flamewing";
