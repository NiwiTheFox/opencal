#ifndef ASMSUB_H
#define ASMSUB_H
/* asmsub.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Unterfunktionen, vermischtes                                              */
/*                                                                           */
/*****************************************************************************/

#include "asmdef.h"
#include "datatypes.h"
#include "striter.h"

#include <stddef.h>
#include <stdio.h>
#include <string.h>

struct sLineComp;
struct sStrComp;
struct as_dynstr;

typedef void (*TSwitchProc)(void);

extern long GTime(void);

extern void UpString(char* s);

extern char* QuotPosQualify(
        char const* s, char Zeichen, as_qualify_quote_fnc_t QualifyQuoteFnc);
#define QuotPos(s, Zeichen) QuotPosQualify(s, Zeichen, NULL)
extern char* QuotMultPosQualify(
        char const* s, char const* pSearch, as_qualify_quote_fnc_t QualifyQuoteFnc);
#define QuotMultPos(s, pSearch) QuotMultPosQualify(s, pSearch, NULL)
extern char* QuotSMultPosQualify(
        char const* s, char const* pStrs, as_qualify_quote_fnc_t QualifyQuoteFnc);
#define QuotSMultPos(s, pStrs) QuotSMultPosQualify(s, pStrs, NULL)

extern char* RQuotPos(char* s, char Zeichen);

extern void KillBlanks(char* s);

extern int CopyNoBlanks(char* pDest, char const* pSrc, size_t MaxLen);

extern char* FirstBlank(char const* s);

extern void SplitString(char* Source, char* Left, char* Right, char* Trenner);

extern ShortInt StrCaseCmp(char const* s1, char const* s2, LongInt Hand1, LongInt Hand2);

extern char* MatchChars(char const* pStr, char const* pPattern, ...);
extern char* MatchCharsRev(char const* pStr, char const* pPattern, ...);

extern char* FindClosingParenthese(char const* pStr);

extern char* FindOpeningParenthese(
        char const* pStrBegin, char const* pStrEnd, char const Bracks[2]);

#ifdef PROFILE_MEMO
static inline Boolean Memo(char const* s) {
    NumMemo++;
    return !strcmp(OpPart.str.p_str, s);
}
#else
#    define Memo(s) (!strcmp(OpPart.str.p_str, (s)))
#endif

extern Boolean AddSuffix(char* s, char const* Suff);

extern void KillSuffix(char* s);

extern char const* NamePart(char const* Name);

extern char* PathPart(char* Name);

extern void FloatString(char* pDest, size_t DestSize, as_float_t f);

struct sTempResult;
extern void StrSym(
        const struct sTempResult* t, Boolean WithSystem, struct as_dynstr* p_dest,
        unsigned Radix);

extern void ResetPageCounter(void);

extern void NewPage(ShortInt Level, Boolean WithFF);

extern void WrLstLine(char const* Line);

extern void SetListLineVal(struct sTempResult* t);

extern void PrintOneLineMuted(
        FILE* pFile, char const* pLine, const struct sLineComp* pMuteComponent,
        const struct sLineComp* pMuteComponent2);
extern void PrLineMarker(
        FILE* pFile, char const* pLine, char const* pPrefix, char const* pTrailer,
        char Marker, const struct sLineComp* pLineComp);

extern LargeWord ProgCounter(void);

extern LargeWord EProgCounter(void);

extern Word Granularity(void);

extern Word ListGran(void);
extern Word gran_bits_unused(void);
extern Word list_gran_bits_unused(void);

extern void ChkSpace(Byte AddrSpace, unsigned AddrSpaceMask);

extern void PrintUseList(void);

extern void ClearUseList(void);

extern int CompressLine(
        char const* TokNam, unsigned TokenNum, struct as_dynstr* p_str,
        Boolean CaseSensitive);

extern void ExpandLine(char const* TokNam, unsigned TokenNum, struct as_dynstr* p_str);

typedef struct sTokenReplacement {
    char const* Text; /* NULL means this token is inactive; "" deletes it */
    size_t      Length;
} tTokenReplacement;

/* Ordinary replacements followed by four special-parameter slots. Source
   must not alias destination. Sequential preserves control-bearing values. */
extern void ExpandTokens(
        char const* Source, tTokenReplacement const* Replacements, unsigned ParamCount,
        Boolean ExpandAttrs, Boolean Sequential, struct as_dynstr* Dest);

extern void KillCtrl(char* Line);

extern void AddCopyright(char const* NewLine);

extern void WriteCopyrights(void (*PrintProc)(char const*));

extern char*   ChkSymbNameUpTo(char const* pSym, char const* pUpTo);
extern Boolean ChkSymbName(char const* pSym);

extern char*   ChkMacSymbNameUpTo(char const* pSym, char const* pUpTo);
extern Boolean ChkMacSymbName(char const* pSym);
extern Boolean ChkMacSymbChar(char ch);

extern unsigned visible_strlen(char const* pSym);

extern void AddIncludeList(char const* NewPath);

extern void RemoveIncludeList(char const* RemPath);

extern void ClearOutList(void);

extern void AddToOutList(char const* NewName);

extern void RemoveFromOutList(char const* OldName);

extern char* MoveFromOutListFirst(void);

extern void ClearShareOutList(void);

extern void AddToShareOutList(char const* NewName);

extern void RemoveFromShareOutList(char const* OldName);

extern char* MoveFromShareOutListFirst(void);

extern void ClearListOutList(void);

extern void AddToListOutList(char const* NewName);

extern void RemoveFromListOutList(char const* OldName);

extern char* MoveFromListOutListFirst(void);

extern void BookKeeping(void);

extern long DTime(long t1, long t2);

extern void exec_init_pass_fncs(void);
extern void AddInitPassProc(SimpProc NewProc);

extern void exec_exit_pass_fncs(void);
extern void add_exit_pass_proc(SimpProc new_proc);

extern void ClearUp(void);
extern void AddClearUpProc(SimpProc NewProc);

extern void asmsub_init(void);

#include "asmerr.h"

#endif /* ASMSUB_H */
