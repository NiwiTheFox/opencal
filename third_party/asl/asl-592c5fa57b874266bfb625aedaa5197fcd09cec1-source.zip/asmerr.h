#ifndef ASMERR_H
#define ASMERR_H
/* asmerr.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Error Handling Functions                                                  */
/*                                                                           */
/*****************************************************************************/

#include "datatypes.h"
#include "errmsg.h"

extern Word ErrorCount, WarnCount;

struct sLineComp;
struct sStrComp;
extern void WrErrorString(
        char const* Message, char const* Add, Boolean Warning, Boolean Fatal,
        char const* pExtendError, const struct sLineComp* pLineComp);

extern void WrError(tErrorNum Num);

extern void WrXError(tErrorNum Num, char const* pExtError);

extern void WrXErrorPos(
        tErrorNum Num, char const* pExtError, const struct sLineComp* pLineComp);

extern void WrStrErrorPos(tErrorNum Num, const struct sStrComp* pStrComp);

/* Describe a delimiter failure at one character of the original component. */
extern void WrBracketErrorPos(const struct sStrComp* arg, size_t offset,
        char actual, char expected, Boolean missing);
extern void WrBracketError(const struct sStrComp* arg, const char* pairs, Boolean quoted);
extern Boolean CheckBrackets(const struct sStrComp* arg, const char* pairs, Boolean quoted);

extern void CodeEXPECT(Word Code);
extern void CodeENDEXPECT(Word Code);

extern Boolean FindAndTakeExpectError(tErrorNum Num);

extern void ChkIO(tErrorNum ErrNo);
extern void ChkXIO(tErrorNum ErrNo, char* pExtError);
extern void ChkStrIO(tErrorNum ErrNo, const struct sStrComp* pComp);

extern void asmerr_warn_relative_add(void);

extern Boolean asmerr_check_fp_dispose_result(int ret, const struct sStrComp* p_arg);

extern void asmerr_init(void);

#endif /* ASMERR_H */
